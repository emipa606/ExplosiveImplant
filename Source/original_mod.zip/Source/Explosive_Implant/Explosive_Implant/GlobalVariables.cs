﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Verse;

namespace Explosive_Implant
{
    static class GlobalVariables
    {
        static public List<HediffWithComps_Explosion> list_obj = new List<HediffWithComps_Explosion>();
        static public List<bool> pawnIsSelected = new List<bool>();
    }
}
